import React from 'react';

function SignUp() {
    return <div>SignUp</div>;
}

export default SignUp;
