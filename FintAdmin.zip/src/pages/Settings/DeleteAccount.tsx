import React from 'react';

function DeleteAccount() {
    return <div>DeleteAccount</div>;
}

export default DeleteAccount;
