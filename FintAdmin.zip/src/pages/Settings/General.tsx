import React from 'react';

function General() {
    return <div>General</div>;
}

export default General;
